With 25 years of experience in web development, I bring a wealth of knowledge and a deep commitment to open source projects. My extensive background has equipped me with the skills to innovate and excel in creating robust, scalable web solutions.

Here is my github: https://github.com/profullstack
Let's chat!

Anthony Ettinger
408-656-2473
https://profullstack.com



Location: SF Bay Area, California

Remote: Yes

Willing to relocate: No

Technologies: JavaScript, Linux, HTML, CSS, Shell, MongoDB, SurrealDB, SQL

Résumé/CV: upon request. See https://profullstack.com and https://github.com/profullstack

Email: anthony@profullstack.com

Phone: +1-408-656-2473
